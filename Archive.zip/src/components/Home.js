import React, { Component } from "react";
// import GetCustomers from "./Customers/GetCustomers";

export class Home extends Component {
  static displayName = Home.name;

  render() {
    return (
      <div>
        <h1>"Hello World"</h1>
      </div>
    );
  }
}
